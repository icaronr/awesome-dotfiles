# awesome-dotfiles

My personal AwesomeWM configs!
